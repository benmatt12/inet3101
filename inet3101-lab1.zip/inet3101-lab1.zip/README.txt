Ben Matthews 5788625

The lab1 program currently only displays a record database menu. The user is able to select one of seven options and is prompted with a message of their selection. The program uses case statements to identify the user's selection and subsequently print out the respective prompt.

The user is first provided the menu selections: print all records, add record, delete the last record, print number of records, print database size, print number of changes, or exit. The user must select a number 1-7 corresponding to what they would like to do. If the user selects an integer <1 or >7, the user will be asked to try again.

.h header, .c c code